import {NextResponse} from "next/server";
import {connectDB} from "@/lib/db";
import Order from "@/models/Order";
export async function GET(){try{await connectDB();const orders=await Order.find().sort({createdAt:-1}).limit(100).lean();return NextResponse.json({orders});}catch(e){return NextResponse.json({error:"Database unavailable"},{status:503});}}
export async function POST(req:Request){try{await connectDB();const b=await req.json();if(!b.customer?.name||!Array.isArray(b.items)||!b.items.length)return NextResponse.json({error:"Customer and items are required"},{status:400});const order=await Order.create({...b,orderNumber:"AFC-"+Date.now()});return NextResponse.json({order},{status:201});}catch(e){return NextResponse.json({error:"Could not create order"},{status:400});}}